<template>
    <header id="header" class="fixed-top d-flex align-items-center">
      <div class="container d-flex align-items-center justify-content-between">
        <div class="logo">
          <h1>
            <a href="/">
              <img
                src="assets/img/logo.png"
                alt="Akeshya Logo"
                class="img-fluid"
              />AKESHYA
            </a>
          </h1>
        </div>
        <nav id="navbar" class="navbar">
          <ul>
            <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
            <li><a class="nav-link scrollto" href="#about">About</a></li>
            <li><a class="nav-link scrollto" href="#services">Services</a></li>
            <li>
              <a class="getstarted scrollto" href="#contact">Contact us</a>
            </li>
          </ul>
          <i class="bi mobile-nav-toggle bi-list"></i>
        </nav>
      </div>
    </header>
  </template>
  
  <script>
  export default {
    name:'nav-bar'
  }

  </script>
  
  <style scoped>
  
   
  </style>
  
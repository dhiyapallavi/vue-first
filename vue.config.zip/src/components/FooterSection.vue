<template>
    <footer id="footer">
      <div class="container">
        <div class="d-flex justify-content-between">
          <div class="Copyright">
            © Copyright <strong>Akeshya</strong>. All Rights Reserved
          </div>
          <div>
            <ul class="d-flex list-unstyled">
              <li class="px-3">
                <a href="./Terms and conditions.pdf" style="text-decoration: none;">Terms and conditions</a>
              </li>
              <li class="px-3">
                <a href="./Refund policy.pdf" style="text-decoration: none;">Refund policy</a>
              </li>
              <li class="px-3">
                <a href="./Privacy policy.pdf" style="text-decoration: none;">Privacy policy</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </footer>
    <a href="#" class="back-to-top d-flex align-items-center justify-content-center active"><i class="bi bi-arrow-up-short"></i></a>
  </template>
  
  <script>
  export default {
    name:'footer-section'
  };
  </script>
  
  <style scoped>
  /* Add component-specific CSS styles here */
  </style>
  